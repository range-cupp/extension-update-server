// ============================================
// RANGE MEDICAL - PRACTICE FUSION EXTENSION
// Side Panel Script v1.5.0 - BIDIRECTIONAL
// ============================================

// Configuration
const SUPABASE_URL = 'https://teivfptpozltpqwahgdl.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRlaXZmcHRwb3psdHBxd2FoZ2RsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ3MTMxNDksImV4cCI6MjA4MDI4OTE0OX0.NrI1AykMBOh91mM9BFvpSH0JwzGrkv5ADDkZinh0elc';
const GHL_API_KEY = 'pit-3077d6b0-6f08-4cb6-b74e-be7dd765e91d';
const GHL_LOCATION_ID = 'WICdvbXmTjQORW6GiHWW';
const UPDATE_URL = 'https://app.range-medical.com/api/extension/version';
const DOWNLOAD_URL = 'https://app.range-medical.com/api/extension/download';
const CURRENT_VERSION = '1.5.0';

// GHL Calendar Mappings - All Range Medical Calendars
const CALENDAR_MAPPINGS = {
  // Lab/Blood Draw Calendars
  'New Patient Blood Draw - Essential': '69363659022462924d66805c',
  'New Patient Blood Draw': '68f01aea7ed18b27a8b12e64',
  'Follow Up Blood Draw': '68fbc3300d41ec836e706680',
  'Follow-Up Blood Draw': '68fbc3300d41ec836e706680',
  'Initial Lab Review': '68fbc3cc4cbe5615edb2016d',
  'Follow Up Lab Review': '68fbc36b4cbe564781b1f35c',
  'Follow-Up Lab Review': '68fbc36b4cbe564781b1f35c',
  'Follow Up Lab Review - Tele-Medicine': '6914afb9ec4f06d1b2609269',
  'Follow Up Lab Review - Telephone Call': '6914afc35cdddbe5fef3bb85',
  'Initial Lab Review - Tele-Medicine': '6914adef7cacf62860839498',
  
  // Injection Calendars
  'Injection - Weight Loss': '68fc0789f5c19143d3386396',
  'Injection - Testosterone': '68fbe09a4866ec6b798932b6',
  'Injection - Peptide': '6900eedaf5009e264f9ded8e',
  'Injection - Medical': '6946d1509a25681dba593fcd',
  'Range Injections': '68f01d9a238b376bfa9a758c',
  'NAD+ Injection (100mg)': '690776fc8dd2f5886acf9f8a',
  'NAD+ Injection': '690776fc8dd2f5886acf9f8a',
  
  // Therapy/Treatment Calendars
  'Hyperbaric Oxygen Therapy': '68fbb36bde21d1840e5f412e',
  'Hyperbaric Oxygen Therapy (HBOT)': '68fbb36bde21d1840e5f412e',
  'HBOT': '68fbb36bde21d1840e5f412e',
  'Red Light Therapy': '68fbb3888eb4bc0d9dc758cb',
  'Range IV': '68efcd8ae4e0ed94b9390a06',
  'IV Therapy': '68efcd8ae4e0ed94b9390a06',
  'High Dose Vitamin C IV': '690d0d03ec7b0073354f70fc',
  'BYO - IV': '690cae20ae8412d0d3abca10',
  
  // Consultation Calendars
  'Initial Consultation': '68efa7f2a4000567ffb24e89',
  'Initial Consultation - Peptide': '690d522562da4d05eed3e98d',
  'Initial Consultation - Telephone': '6927b9d04a229b065d560def',
  'Follow-Up Consultation': '68efc2e5c36a832e51cada96',
  'Follow Up Consultation': '68efc2e5c36a832e51cada96',
  'The Range Assessment': '69769eed725303dcad0eb2da',
  
  // Other
  'Medication Pickup': '690bfaf5fd20ba6d2a8b38c4',
  
  // Common variations and abbreviations
  'Blood Draw': '68f01aea7ed18b27a8b12e64',
  'Lab Draw': '68f01aea7ed18b27a8b12e64',
  'Lab Review': '68fbc3cc4cbe5615edb2016d',
  'Consultation': '68efa7f2a4000567ffb24e89',
  'IV': '68efcd8ae4e0ed94b9390a06',
  'Injection': '68f01d9a238b376bfa9a758c',
};

const DEFAULT_CALENDAR_ID = '68f01aea7ed18b27a8b12e64'; // Default to New Patient Blood Draw


// State
let selectedPatient = null;
let selectedAppointment = null;
let searchTimeout = null;

// DOM elements
const searchInput = document.getElementById('searchInput');
const statusEl = document.getElementById('status');
const patientList = document.getElementById('patientList');
const appointmentsSection = document.getElementById('appointmentsSection');
const appointmentsList = document.getElementById('appointmentsList');
const documentsSection = document.getElementById('documentsSection');
const documentsList = document.getElementById('documentsList');
const actionsSection = document.getElementById('actionsSection');
const fillDemoBtn = document.getElementById('fillDemoBtn');
const fillApptBtn = document.getElementById('fillApptBtn');
const capturePFApptBtn = document.getElementById('capturePFApptBtn');
const pageIndicator = document.getElementById('pageIndicator');

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  searchInput.addEventListener('input', handleSearch);
  fillDemoBtn.addEventListener('click', fillDemographics);
  fillApptBtn.addEventListener('click', fillAppointment);
  capturePFApptBtn?.addEventListener('click', captureAndCreateGHLAppointment);
  
  checkCurrentPage();
  checkForUpdates();
});

// ============================================
// UPDATE CHECKING
// ============================================
async function checkForUpdates() {
  try {
    const response = await fetch(UPDATE_URL);
    if (!response.ok) return;
    const data = await response.json();
    if (data.version && isNewerVersion(data.version, CURRENT_VERSION)) {
      showUpdateBanner(data.version, data.notes || 'Bug fixes and improvements');
    }
  } catch (e) {
    console.log('Update check failed:', e);
  }
}

function isNewerVersion(remote, local) {
  const remoteParts = remote.split('.').map(Number);
  const localParts = local.split('.').map(Number);
  for (let i = 0; i < Math.max(remoteParts.length, localParts.length); i++) {
    const r = remoteParts[i] || 0;
    const l = localParts[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

function showUpdateBanner(newVersion, notes) {
  const banner = document.createElement('div');
  banner.id = 'updateBanner';
  banner.innerHTML = `
    <div style="background:linear-gradient(135deg,#0ea5e9,#0284c7);color:white;padding:12px 16px;border-radius:10px;margin-bottom:16px;">
      <div style="font-weight:600;margin-bottom:4px;">🎉 Update Available (v${newVersion})</div>
      <div style="font-size:12px;opacity:0.9;margin-bottom:10px;">${notes}</div>
      <button id="downloadUpdate" style="background:white;color:#0284c7;border:none;padding:8px 16px;border-radius:6px;font-weight:500;cursor:pointer;font-size:13px;">Download Update</button>
      <button id="dismissUpdate" style="background:transparent;color:white;border:1px solid rgba(255,255,255,0.3);padding:8px 12px;border-radius:6px;margin-left:8px;cursor:pointer;font-size:13px;">Later</button>
    </div>
  `;
  const container = document.querySelector('.container');
  container.insertBefore(banner, container.children[1]);
  document.getElementById('downloadUpdate').addEventListener('click', () => window.open(DOWNLOAD_URL, '_blank'));
  document.getElementById('dismissUpdate').addEventListener('click', () => banner.remove());
}

// ============================================
// PAGE DETECTION
// ============================================
async function checkCurrentPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    const url = tab.url;
    if (url.includes('charts/patients/add')) {
      pageIndicator.textContent = '📝 Ready to fill patient demographics';
      pageIndicator.style.display = 'block';
    } else if (url.includes('/schedule')) {
      pageIndicator.textContent = '📅 Ready to fill appointment or capture to GHL';
      pageIndicator.style.display = 'block';
      // Show capture button when on schedule page
      if (capturePFApptBtn) capturePFApptBtn.style.display = 'flex';
    } else if (url.includes('/charts/') && url.includes('/documents')) {
      pageIndicator.textContent = '📄 Ready to upload documents';
      pageIndicator.style.display = 'block';
    } else if (url.includes('practicefusion.com')) {
      pageIndicator.style.display = 'none';
    } else {
      pageIndicator.textContent = '⚠️ Open Practice Fusion to use this extension';
      pageIndicator.style.display = 'block';
      pageIndicator.style.background = '#fef2f2';
      pageIndicator.style.color = '#dc2626';
    }
  } catch (e) {
    console.log('Page check error:', e);
  }
}

// ============================================
// SEARCH - Both intakes AND ghl_contacts
// ============================================
function handleSearch() {
  clearTimeout(searchTimeout);
  const query = searchInput.value.trim();
  if (query.length < 2) {
    patientList.innerHTML = '';
    actionsSection.style.display = 'none';
    appointmentsSection.style.display = 'none';
    documentsSection.style.display = 'none';
    return;
  }
  searchTimeout = setTimeout(() => searchPatients(query), 300);
}

async function searchPatients(query) {
  showStatus('Searching...', 'info');
  try {
    const cleanQuery = query.trim();
    const cleanDigits = cleanQuery.replace(/\D/g, '');
    const isPhoneSearch = cleanDigits.length >= 7;
    
    let intakeResults = [];
    let ghlResults = [];
    
    let intakeUrl = `${SUPABASE_URL}/rest/v1/intakes?select=*`;
    let ghlUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?select=*`;
    
    if (isPhoneSearch) {
      const phoneSearch = cleanDigits.slice(-7);
      intakeUrl += `&phone=ilike.*${phoneSearch}*`;
      ghlUrl += `&phone=ilike.*${phoneSearch}*`;
    } else {
      const nameParts = cleanQuery.toLowerCase().split(' ').filter(p => p.length > 0);
      if (nameParts.length >= 2) {
        intakeUrl += `&first_name=ilike.*${nameParts[0]}*&last_name=ilike.*${nameParts[1]}*`;
        ghlUrl += `&first_name=ilike.*${nameParts[0]}*&last_name=ilike.*${nameParts[1]}*`;
      } else {
        intakeUrl += `&or=(first_name.ilike.*${nameParts[0]}*,last_name.ilike.*${nameParts[0]}*)`;
        ghlUrl += `&or=(first_name.ilike.*${nameParts[0]}*,last_name.ilike.*${nameParts[0]}*)`;
      }
    }
    
    intakeUrl += '&order=created_at.desc&limit=15';
    ghlUrl += '&order=updated_at.desc&limit=15';
    
    const intakeResponse = await fetch(intakeUrl, {
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
    });
    if (intakeResponse.ok) {
      intakeResults = await intakeResponse.json();
      intakeResults = intakeResults.map(p => ({ ...p, _source: 'intake' }));
    }
    
    const ghlResponse = await fetch(ghlUrl, {
      headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
    });
    if (ghlResponse.ok) {
      ghlResults = await ghlResponse.json();
      ghlResults = ghlResults.map(p => ({ ...p, _source: 'ghl' }));
    }
    
    // Merge results, preferring intake records
    const seenPhones = new Set();
    const seenEmails = new Set();
    const patients = [];
    
    for (const patient of intakeResults) {
      const phone = (patient.phone || '').replace(/\D/g, '').slice(-10);
      const email = (patient.email || '').toLowerCase();
      if (phone) seenPhones.add(phone);
      if (email) seenEmails.add(email);
      patients.push(patient);
    }
    
    for (const patient of ghlResults) {
      const phone = (patient.phone || '').replace(/\D/g, '').slice(-10);
      const email = (patient.email || '').toLowerCase();
      if (phone && seenPhones.has(phone)) continue;
      if (email && seenEmails.has(email)) continue;
      if (phone) seenPhones.add(phone);
      if (email) seenEmails.add(email);
      patients.push(patient);
    }
    
    console.log(`Search results: ${intakeResults.length} intakes, ${ghlResults.length} GHL, ${patients.length} merged`);
    
    if (patients.length === 0) {
      patientList.innerHTML = '<div class="no-results">No patients found</div>';
      showStatus('', '');
      return;
    }
    
    displayPatients(patients);
    showStatus('', '');
  } catch (error) {
    console.error('Search error:', error);
    showStatus('Search failed. Please try again.', 'error');
  }
}


function displayPatients(patients) {
  patientList.innerHTML = patients.map(p => {
    const isGHL = p._source === 'ghl';
    const badge = isGHL ? '<span style="background:#f97316;color:white;padding:2px 6px;border-radius:4px;font-size:10px;margin-left:8px;">GHL</span>' : '';
    return `
      <div class="patient-card" data-id="${p.id}" data-source="${p._source}">
        <div class="patient-name">${p.first_name} ${p.last_name}${badge}</div>
        <div class="patient-info">
          <span>📞 ${formatPhone(p.phone)}</span>
          ${p.date_of_birth ? `<span>🎂 ${formatDate(p.date_of_birth)}</span>` : ''}
          ${p.email ? `<span>✉️ ${p.email}</span>` : ''}
        </div>
      </div>
    `;
  }).join('');
  
  patientList._patients = patients;
  
  patientList.querySelectorAll('.patient-card').forEach(card => {
    card.addEventListener('click', () => {
      const id = card.dataset.id;
      const patient = patients.find(p => p.id === id);
      if (patient) selectPatient(patient);
    });
  });
}

async function selectPatient(patient) {
  patientList.querySelectorAll('.patient-card').forEach(c => c.classList.remove('selected'));
  const card = patientList.querySelector(`[data-id="${patient.id}"]`);
  if (card) card.classList.add('selected');
  
  showStatus('Loading patient data...', 'info');
  
  // Fetch documents
  patient.documents = await fetchPatientDocuments(
    patient.id, patient.phone, patient.email,
    patient.first_name?.trim(), patient.last_name?.trim(),
    patient.pdf_url, patient.photo_id_url
  );
  
  // Fetch appointments
  if (patient.ghl_contact_id) {
    console.log(`📅 Fetching appointments using GHL ID: ${patient.ghl_contact_id}`);
    patient.appointments = await fetchAppointmentsForContact(patient.ghl_contact_id);
  } else if (patient.phone) {
    console.log(`📅 Fetching appointments using phone: ${patient.phone}`);
    const ghlContactId = await findGHLContactId(patient.phone, patient.email, patient.first_name, patient.last_name);
    if (ghlContactId) {
      console.log(`📅 Found GHL contact ID: ${ghlContactId}`);
      patient.appointments = await fetchAppointmentsForContact(ghlContactId);
    } else {
      patient.appointments = [];
    }
  } else {
    patient.appointments = [];
  }
  console.log(`📅 ${patient.first_name} has ${patient.appointments?.length || 0} appointments`);
  
  selectedPatient = patient;
  selectedAppointment = null;
  
  // Display documents with download buttons
  if (patient.documents?.length > 0) {
    documentsSection.style.display = 'block';
    
    // Add Download All button at the top
    const downloadAllBtn = `
      <button id="downloadAllBtn" class="download-all-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="7 10 12 15 17 10"/>
          <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        Download All (${patient.documents.length})
      </button>
    `;
    
    documentsList.innerHTML = downloadAllBtn + patient.documents.map(doc => {
      const isImage = doc.isImage || doc.url?.match(/\.(png|jpg|jpeg|gif|webp)$/i) || doc.url?.includes('/photo-ids/');
      const iconColor = isImage ? '#2563eb' : '#dc2626';
      const iconBg = isImage ? '#dbeafe' : '#fee2e2';
      const icon = isImage 
        ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>`
        : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${iconColor}" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>`;
      
      const safeName = `${patient.first_name}_${patient.last_name}`.replace(/[^a-zA-Z0-9]/g, '_');
      const docType = doc.type.replace(/[^a-zA-Z0-9]/g, '_');
      const ext = isImage ? (doc.url?.match(/\.(png|jpg|jpeg|gif|webp)$/i)?.[1] || 'png') : 'pdf';
      const fileName = `${safeName}_${docType}.${ext}`;
      
      return `
        <div class="doc-item">
          <div style="display:flex;align-items:center;gap:8px;flex:1;">
            <div style="background:${iconBg};padding:6px;border-radius:6px;display:flex;">${icon}</div>
            <div>
              <div class="doc-name">${doc.type}</div>
              <div style="font-size:10px;color:#94a3b8;">${fileName}</div>
            </div>
          </div>
          <button class="download-btn" data-url="${doc.url}" data-filename="${fileName}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Download
          </button>
        </div>
      `;
    }).join('');
    
    // Add download handlers
    documentsList.querySelectorAll('.download-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const url = btn.dataset.url;
        const filename = btn.dataset.filename;
        btn.textContent = 'Downloading...';
        btn.disabled = true;
        try {
          const response = await fetch(url);
          const blob = await response.blob();
          const blobUrl = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = blobUrl;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(blobUrl);
          btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Done`;
          setTimeout(() => {
            btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download`;
            btn.disabled = false;
          }, 2000);
        } catch (err) {
          console.error('Download failed:', err);
          btn.textContent = 'Failed';
          btn.disabled = false;
        }
      });
    });
    
    // Add Download All handler
    const downloadAllBtnEl = document.getElementById('downloadAllBtn');
    if (downloadAllBtnEl) {
      downloadAllBtnEl.addEventListener('click', async () => {
        const allBtns = documentsList.querySelectorAll('.download-btn');
        downloadAllBtnEl.textContent = 'Downloading...';
        downloadAllBtnEl.disabled = true;
        
        for (const btn of allBtns) {
          const url = btn.dataset.url;
          const filename = btn.dataset.filename;
          try {
            const response = await fetch(url);
            const blob = await response.blob();
            const blobUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = blobUrl;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(blobUrl);
            // Small delay between downloads
            await new Promise(r => setTimeout(r, 300));
          } catch (err) {
            console.error('Download failed:', err);
          }
        }
        
        downloadAllBtnEl.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> All Downloaded!`;
        setTimeout(() => {
          downloadAllBtnEl.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download All (${patient.documents.length})`;
          downloadAllBtnEl.disabled = false;
        }, 2000);
      });
    }
  } else {
    documentsSection.style.display = 'none';
  }
  
  // Display appointments
  if (patient.appointments?.length > 0) {
    appointmentsSection.style.display = 'block';
    appointmentsList.innerHTML = patient.appointments.map(appt => {
      const isPast = appt.isPast;
      const statusColor = isPast ? '#94a3b8' : '#16a34a';
      const statusText = isPast ? 'Past' : 'Upcoming';
      return `
        <div class="appointment-item ${selectedAppointment?.id === appt.id ? 'selected' : ''}" data-id="${appt.id}">
          <div class="appointment-date">${appt.date} at ${appt.time}</div>
          <div class="appointment-type">${appt.title}</div>
          <div style="font-size:11px;color:${statusColor};margin-top:4px;">${statusText}</div>
        </div>
      `;
    }).join('');
    
    appointmentsList.querySelectorAll('.appointment-item').forEach(item => {
      item.addEventListener('click', () => {
        appointmentsList.querySelectorAll('.appointment-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        selectedAppointment = patient.appointments.find(a => a.id === item.dataset.id);
      });
    });
  } else {
    appointmentsSection.style.display = 'none';
  }
  
  actionsSection.style.display = 'flex';
  showStatus('', '');
}

// ============================================
// FETCH DOCUMENTS
// ============================================
async function fetchPatientDocuments(patientId, phone, email, firstName, lastName, pdfUrl, photoIdUrl) {
  const allDocs = [];
  firstName = firstName?.trim();
  lastName = lastName?.trim();
  console.log('🔍 Fetching documents for:', { patientId, phone, email, firstName, lastName });
  
  if (pdfUrl) {
    allDocs.push({ type: 'Medical Intake Form', url: pdfUrl });
  }
  if (photoIdUrl) {
    allDocs.push({ type: "Driver's License / Photo ID", url: photoIdUrl, isImage: true });
  }
  
  if (patientId && !pdfUrl) {
    try {
      const intakeUrl = `${SUPABASE_URL}/rest/v1/intakes?id=eq.${patientId}&select=pdf_url,photo_id_url`;
      const intakeRes = await fetch(intakeUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const intakes = await intakeRes.json();
      if (intakes?.[0]?.pdf_url) allDocs.push({ type: 'Medical Intake Form', url: intakes[0].pdf_url });
      if (intakes?.[0]?.photo_id_url) allDocs.push({ type: "Driver's License / Photo ID", url: intakes[0].photo_id_url, isImage: true });
    } catch (e) { console.log('Intake fetch error:', e); }
  }
  
  // Fetch consents
  try {
    if (phone) {
      const cleanPhone = phone.replace(/\D/g, '');
      const consentsUrl = `${SUPABASE_URL}/rest/v1/consents?phone=ilike.*${cleanPhone.slice(-7)}*&select=consent_type,pdf_url`;
      const consentsRes = await fetch(consentsUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const consents = await consentsRes.json();
      console.log('Found consents by phone:', consents?.length || 0);
      consents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
    
    if (allDocs.length <= 2 && email) {
      const emailUrl = `${SUPABASE_URL}/rest/v1/consents?email=ilike.${encodeURIComponent(email)}&select=consent_type,pdf_url`;
      const emailRes = await fetch(emailUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const emailConsents = await emailRes.json();
      emailConsents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
    
    if (allDocs.length <= 2 && firstName && lastName) {
      const nameUrl = `${SUPABASE_URL}/rest/v1/consents?first_name=ilike.${encodeURIComponent(firstName)}&last_name=ilike.${encodeURIComponent(lastName)}&select=consent_type,pdf_url`;
      const nameRes = await fetch(nameUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      const nameConsents = await nameRes.json();
      nameConsents?.forEach(c => {
        if (c.pdf_url && !allDocs.find(d => d.url === c.pdf_url)) {
          allDocs.push({ type: c.consent_type || 'Consent Form', url: c.pdf_url });
        }
      });
    }
  } catch (e) { console.log('Consents fetch error:', e); }
  
  console.log('✅ Final document count:', allDocs.length);
  return allDocs;
}

// ============================================
// GHL APPOINTMENTS
// ============================================
async function findGHLContactId(phone, email, firstName, lastName) {
  try {
    const cleanPhone = phone?.replace(/\D/g, '') || '';
    const last7 = cleanPhone.slice(-7);
    
    // First try Supabase synced contacts
    if (last7) {
      const phoneUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?phone=ilike.*${last7}*&select=ghl_contact_id&limit=1`;
      const phoneResponse = await fetch(phoneUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      if (phoneResponse.ok) {
        const results = await phoneResponse.json();
        if (results.length > 0 && results[0].ghl_contact_id) {
          console.log('📇 Found contact in synced table by phone');
          return results[0].ghl_contact_id;
        }
      }
    }
    
    if (email) {
      const emailUrl = `${SUPABASE_URL}/rest/v1/ghl_contacts?email=ilike.${encodeURIComponent(email)}&select=ghl_contact_id&limit=1`;
      const emailResponse = await fetch(emailUrl, {
        headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}` }
      });
      if (emailResponse.ok) {
        const results = await emailResponse.json();
        if (results.length > 0 && results[0].ghl_contact_id) {
          console.log('📇 Found contact in synced table by email');
          return results[0].ghl_contact_id;
        }
      }
    }
    
    // Fallback: Search GHL directly if not in synced table
    console.log('📇 Contact not in synced table, searching GHL directly...');
    const searchQuery = firstName && lastName ? `${firstName} ${lastName}` : (cleanPhone || email);
    if (searchQuery) {
      const ghlSearchUrl = `https://services.leadconnectorhq.com/contacts/?locationId=${GHL_LOCATION_ID}&query=${encodeURIComponent(searchQuery)}&limit=5`;
      const ghlResponse = await fetch(ghlSearchUrl, {
        headers: {
          'Authorization': `Bearer ${GHL_API_KEY}`,
          'Version': '2021-07-28',
          'Content-Type': 'application/json'
        }
      });
      
      if (ghlResponse.ok) {
        const ghlData = await ghlResponse.json();
        const contacts = ghlData.contacts || [];
        
        // Find matching contact by phone or email
        for (const c of contacts) {
          const cPhone = (c.phone || '').replace(/\D/g, '');
          const cEmail = (c.email || '').toLowerCase();
          
          if (cleanPhone && cPhone.includes(last7)) {
            console.log('📇 Found contact in GHL by phone:', c.id);
            return c.id;
          }
          if (email && cEmail === email.toLowerCase()) {
            console.log('📇 Found contact in GHL by email:', c.id);
            return c.id;
          }
        }
        
        // If only one result and name matches, use it
        if (contacts.length === 1) {
          console.log('📇 Found single contact in GHL:', contacts[0].id);
          return contacts[0].id;
        }
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error finding GHL contact ID:', error);
    return null;
  }
}

async function fetchAppointmentsForContact(contactId) {
  try {
    const now = new Date();
    const appointmentsUrl = `https://services.leadconnectorhq.com/contacts/${contactId}/appointments`;
    console.log('Fetching contact appointments:', appointmentsUrl);
    
    const response = await fetch(appointmentsUrl, {
      headers: {
        'Authorization': `Bearer ${GHL_API_KEY}`,
        'Version': '2021-07-28',
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.log('GHL appointments fetch failed:', response.status);
      return [];
    }
    
    const data = await response.json();
    console.log('Raw appointment response:', data);
    const events = data.events || [];
    console.log('Found appointments:', events.length);
    
    const pastDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const futureDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    
    return events.map(event => {
      const eventDate = new Date(event.startTime);
      return {
        id: event.id,
        title: event.title || 'Appointment',
        date: eventDate.toLocaleDateString('en-US'),
        time: eventDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
        startTime: event.startTime,
        isPast: eventDate < now
      };
    })
    .filter(a => {
      const d = new Date(a.startTime);
      return d >= pastDate && d <= futureDate;
    })
    .sort((a, b) => new Date(a.startTime) - new Date(b.startTime));
  } catch (error) {
    console.error('Error fetching appointments:', error);
    return [];
  }
}

// ============================================
// ACTIONS - FILL DEMOGRAPHICS
// ============================================
async function fillDemographics() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  showStatus('Filling demographics...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const patient = {
    firstName: selectedPatient.first_name?.trim(),
    lastName: selectedPatient.last_name?.trim(),
    email: selectedPatient.email,
    phone: selectedPatient.phone,
    dob: selectedPatient.date_of_birth,
    gender: selectedPatient.gender,
    address: selectedPatient.street_address,
    city: selectedPatient.city,
    state: selectedPatient.state,
    zip: selectedPatient.postal_code
  };
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFDemographics,
      args: [patient]
    });
    showStatus('✓ Demographics filled!', 'success');
  } catch (error) {
    console.error('Fill error:', error);
    showStatus('Failed to fill. Make sure you\'re on the Add Patient page.', 'error');
  }
}

function fillPFDemographics(patient) {
  console.log('🏥 Filling demographics for:', patient);
  
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      if (label.textContent.toUpperCase().includes(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) return document.getElementById(forId);
        const input = label.querySelector('input, select');
        if (input) return input;
        const next = label.nextElementSibling;
        if (next?.tagName === 'INPUT' || next?.tagName === 'SELECT') return next;
      }
    }
    return null;
  }
  
  function findByDataElement(elementName) {
    return document.querySelector(`[data-element="${elementName}"]`);
  }
  
  // Find field by multiple strategies
  function findField(dataElement, ...labelTexts) {
    let el = findByDataElement(dataElement);
    if (el) return el;
    for (const label of labelTexts) {
      el = findByLabel(label);
      if (el) return el;
    }
    // Try placeholder text
    for (const label of labelTexts) {
      el = document.querySelector(`input[placeholder*="${label}" i]`);
      if (el) return el;
    }
    // Try aria-label
    for (const label of labelTexts) {
      el = document.querySelector(`input[aria-label*="${label}" i]`);
      if (el) return el;
    }
    return null;
  }
  
  // Standard value setter with full event dispatch
  function setVal(el, val) {
    if (!el || !val) return false;
    
    // Try native input setter first (works with React/Angular)
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype, 'value'
    )?.set;
    
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(el, val);
    } else {
      el.value = val;
    }
    
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  
  // Simulate typing character by character (for masked/framework-controlled inputs)
  function simulateTyping(el, text) {
    if (!el || !text) return false;
    
    el.focus();
    el.click();
    
    // Clear existing value
    el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Also try select all + delete
    el.select?.();
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Backspace', code: 'Backspace', bubbles: true }));
    
    // Type each character
    for (const char of text) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: `Key${char.toUpperCase()}`, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keypress', { key: char, code: `Key${char.toUpperCase()}`, bubbles: true, charCode: char.charCodeAt(0) }));
      
      // Use InputEvent which Angular/React listen to
      el.dispatchEvent(new InputEvent('beforeinput', { data: char, inputType: 'insertText', bubbles: true, cancelable: true }));
      
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      const currentVal = el.value;
      if (nativeSetter) {
        nativeSetter.call(el, currentVal + char);
      } else {
        el.value = currentVal + char;
      }
      
      el.dispatchEvent(new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: `Key${char.toUpperCase()}`, bubbles: true }));
    }
    
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    
    return el.value.length > 0;
  }
  
  // Enhanced DOB setter - tries multiple strategies
  function setDOB(el, dobStr) {
    if (!el || !dobStr) return false;
    
    console.log('🎂 Setting DOB on field:', el.tagName, el.type, el.className, el.id, el.name);
    console.log('🎂 DOB value:', dobStr);
    console.log('🎂 Field placeholder:', el.placeholder);
    
    const [year, month, day] = dobStr.split('-');
    const mmddyyyy = `${month}/${day}/${year}`;
    const mmddyy = `${month}/${day}/${year.slice(-2)}`;
    const digitsOnly = `${month}${day}${year}`;
    
    // Strategy 0: AGGRESSIVE FOCUS - Click and focus multiple times
    console.log('🎂 Strategy 0: Aggressive focus');
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.focus();
    el.click();
    setTimeout(() => el.focus(), 10);
    setTimeout(() => el.click(), 20);
    
    // Strategy 1: If it's a date input type, use yyyy-mm-dd format
    if (el.type === 'date') {
      console.log('🎂 Strategy 1: HTML date input');
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) {
        nativeSetter.call(el, dobStr);
      } else {
        el.value = dobStr;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      if (el.value) {
        console.log('🎂 Strategy 1 WORKED:', el.value);
        return true;
      }
    }
    
    // Strategy 2: Clear field first, then Native setter with MM/DD/YYYY
    console.log('🎂 Strategy 2: Clear + Native setter with MM/DD/YYYY');
    el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) {
      nativeSetter.call(el, mmddyyyy);
    } else {
      el.value = mmddyyyy;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    if (el.value && el.value.includes(month)) {
      console.log('🎂 Strategy 2 WORKED:', el.value);
      return true;
    }
    
    // Strategy 3: Simulate typing digits only (for masked inputs like __/__/____)
    console.log('🎂 Strategy 3: Typing digits only for masked input');
    el.value = '';
    if (simulateTyping(el, digitsOnly)) {
      if (el.value && el.value.length >= 6) {
        console.log('🎂 Strategy 3 WORKED:', el.value);
        return true;
      }
    }
    
    // Strategy 4: Simulate typing MM/DD/YYYY with slashes
    console.log('🎂 Strategy 4: Typing MM/DD/YYYY with slashes');
    el.value = '';
    if (simulateTyping(el, mmddyyyy)) {
      if (el.value && el.value.includes(month)) {
        console.log('🎂 Strategy 4 WORKED:', el.value);
        return true;
      }
    }
    
    // Strategy 5: Character by character with individual focus
    console.log('🎂 Strategy 5: Ultra-slow character typing');
    el.value = '';
    el.focus();
    for (let i = 0; i < digitsOnly.length; i++) {
      const char = digitsOnly[i];
      el.focus();
      const keyEvent = new KeyboardEvent('keydown', { key: char, code: `Digit${char}`, bubbles: true });
      el.dispatchEvent(keyEvent);
      if (nativeSetter) {
        nativeSetter.call(el, el.value + char);
      } else {
        el.value += char;
      }
      el.dispatchEvent(new Event('input', { bubbles: true, data: char }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: `Digit${char}`, bubbles: true }));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    if (el.value && el.value.length >= 6) {
      console.log('🎂 Strategy 5 WORKED:', el.value);
      return true;
    }
    
    // Strategy 6: Try using execCommand (works in some legacy frameworks)
    console.log('🎂 Strategy 6: execCommand insertText');
    el.focus();
    el.select?.();
    try {
      document.execCommand('selectAll', false, null);
      document.execCommand('delete', false, null);
      document.execCommand('insertText', false, mmddyyyy);
      if (el.value && el.value.includes(month)) {
        console.log('🎂 Strategy 6 WORKED:', el.value);
        return true;
      }
    } catch(e) {
      console.log('🎂 execCommand failed:', e);
    }
    
    // Strategy 7: Direct property assignment as last resort
    console.log('🎂 Strategy 7: Direct assignment fallback');
    el.value = mmddyyyy;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    
    console.log('🎂 Final DOB value after all strategies:', el.value);
    return el.value && el.value.length > 0;
    return el.value.length > 0;
  }
  
  let filled = 0;
  
  // Standard fields
  if (setVal(findField('first-name', 'FIRST', 'FIRST NAME'), patient.firstName)) filled++;
  if (setVal(findField('last-name', 'LAST', 'LAST NAME'), patient.lastName)) filled++;
  if (setVal(findField('email-address', 'EMAIL', 'E-MAIL'), patient.email)) filled++;
  if (setVal(findField('mobile-phone', 'MOBILE', 'PHONE', 'CELL'), patient.phone?.replace(/\D/g, ''))) filled++;
  if (setVal(findField('address-line1', 'ADDRESS LINE 1', 'ADDRESS', 'STREET'), patient.address)) filled++;
  if (setVal(findField('city', 'CITY'), patient.city)) filled++;
  if (setVal(findField('zip', 'ZIP', 'POSTAL', 'ZIPCODE'), patient.zip)) filled++;
  
  // DOB - enhanced multi-strategy approach
  if (patient.dob) {
    const dobField = findField('date-of-birth', 'DATE OF BIRTH', 'DOB', 'BIRTH DATE', 'BIRTHDATE', 'BIRTHDAY');
    if (dobField) {
      if (setDOB(dobField, patient.dob)) filled++;
    } else {
      console.log('🎂 DOB field not found, searching by common selectors...');
      // Try common CSS selectors for DOB fields
      const dobSelectors = [
        'input[name*="birth" i]', 'input[name*="dob" i]', 'input[name*="dateOfBirth" i]',
        'input[id*="birth" i]', 'input[id*="dob" i]', 'input[id*="dateOfBirth" i]',
        'input[placeholder*="birth" i]', 'input[placeholder*="MM/DD" i]', 'input[placeholder*="mm/dd" i]',
        'input[data-field*="birth" i]', 'input[data-field*="dob" i]',
        'input[aria-label*="birth" i]', 'input[aria-label*="dob" i]'
      ];
      for (const selector of dobSelectors) {
        const el = document.querySelector(selector);
        if (el) {
          console.log('🎂 Found DOB via selector:', selector);
          if (setDOB(el, patient.dob)) { filled++; break; }
        }
      }
    }
  }
  
  // State field
  const stateField = findField('state', 'STATE');
  if (stateField && patient.state) {
    if (stateField.tagName === 'SELECT') {
      const options = stateField.querySelectorAll('option');
      for (const opt of options) {
        if (opt.textContent.toLowerCase().includes(patient.state.toLowerCase()) || 
            opt.value.toLowerCase() === patient.state.toLowerCase()) {
          stateField.value = opt.value;
          stateField.dispatchEvent(new Event('change', { bubbles: true }));
          filled++;
          break;
        }
      }
    } else {
      setVal(stateField, patient.state);
      filled++;
    }
  }
  
  // Gender
  if (patient.gender) {
    const genderMap = {
      'male': ['male', 'm'],
      'female': ['female', 'f'],
      'other': ['other', 'non-binary', 'nonbinary', 'x']
    };
    const genderLower = patient.gender.toLowerCase();
    const matchTerms = genderMap[genderLower] || [genderLower];
    
    // Try radio buttons first
    const radios = document.querySelectorAll('input[type="radio"]');
    let genderSet = false;
    for (const radio of radios) {
      const label = radio.closest('label') || document.querySelector(`label[for="${radio.id}"]`);
      const labelText = label?.textContent?.toLowerCase()?.trim() || '';
      const radioValue = radio.value?.toLowerCase() || '';
      if (matchTerms.some(term => labelText.includes(term) || radioValue === term)) {
        radio.click();
        radio.checked = true;
        radio.dispatchEvent(new Event('change', { bubbles: true }));
        filled++;
        genderSet = true;
        break;
      }
    }
    
    // Try select dropdown if no radio
    if (!genderSet) {
      const genderSelect = findField('sex', 'SEX', 'GENDER');
      if (genderSelect?.tagName === 'SELECT') {
        const options = genderSelect.querySelectorAll('option');
        for (const opt of options) {
          if (matchTerms.some(term => opt.textContent.toLowerCase().includes(term) || opt.value.toLowerCase() === term)) {
            genderSelect.value = opt.value;
            genderSelect.dispatchEvent(new Event('change', { bubbles: true }));
            filled++;
            break;
          }
        }
      }
    }
  }
  
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled };
}

// ============================================
// ACTIONS - FILL APPOINTMENT
// ============================================
async function fillAppointment() {
  if (!selectedPatient) {
    showStatus('Please select a patient first', 'error');
    return;
  }
  showStatus('Filling appointment...', 'info');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const patientName = `${selectedPatient.first_name} ${selectedPatient.last_name}`;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fillPFAppointment,
      args: [patientName]
    });
    showStatus('✓ Appointment info filled!', 'success');
  } catch (error) {
    console.error('Appointment fill error:', error);
    showStatus('Failed to fill. Make sure appointment dialog is open.', 'error');
  }
}

function fillPFAppointment(patientName) {
  console.log('🏥 Filling appointment for:', patientName);
  const searchFields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
  for (const field of searchFields) {
    if (field.offsetParent !== null) {
      field.value = patientName;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
      field.focus();
      console.log('✅ Filled patient search field');
      break;
    }
  }
  return { success: true };
}

// ============================================
// UTILITIES
// ============================================
function showStatus(message, type) {
  if (!message) { statusEl.style.display = 'none'; return; }
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}

function formatPhone(phone) {
  if (!phone) return '';
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) return `(${cleaned.slice(0,3)}) ${cleaned.slice(3,6)}-${cleaned.slice(6)}`;
  return phone;
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  return `${month}/${day}/${year}`;
}

// ============================================
// BIDIRECTIONAL FUNCTIONALITY (PF → GHL)
// Added in v1.5.0
// ============================================

// Main function to capture PF appointment and create in GHL
async function captureAndCreateGHLAppointment() {
  showStatus('Capturing appointment from Practice Fusion...', 'info');
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Execute script to scrape appointment data from PF
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapePFAppointment
    });
    
    if (!result?.result) {
      showStatus('Could not find appointment details on this page', 'error');
      return;
    }
    
    const apptData = result.result;
    console.log('📅 Captured appointment:', apptData);
    
    if (!apptData.patientName || !apptData.startTime) {
      showStatus('Missing required appointment details (patient name or time)', 'error');
      return;
    }
    
    showStatus('Finding patient in GHL...', 'info');
    
    // Find the GHL contact ID for this patient
    const contactId = await findGHLContactByName(apptData.patientName);
    
    if (!contactId) {
      showStatus(`Could not find patient "${apptData.patientName}" in GHL. Please create contact first.`, 'error');
      return;
    }
    
    console.log('📇 Found GHL contact:', contactId);
    showStatus('Creating appointment in GHL...', 'info');
    
    // Map PF appointment type to GHL calendar
    const calendarId = getCalendarId(apptData.appointmentType);
    console.log('📅 Using calendar:', calendarId, 'for type:', apptData.appointmentType);
    
    // Create the appointment in GHL
    const ghlAppt = await createGHLAppointment({
      contactId,
      calendarId,
      startTime: apptData.startTime,
      endTime: apptData.endTime,
      title: apptData.appointmentType || 'Appointment',
      notes: apptData.notes
    });
    
    if (ghlAppt) {
      showStatus('✓ Appointment created in GHL!', 'success');
      console.log('✅ GHL Appointment created:', ghlAppt);
    } else {
      showStatus('Failed to create appointment in GHL', 'error');
    }
    
  } catch (error) {
    console.error('Capture error:', error);
    showStatus('Error capturing appointment: ' + error.message, 'error');
  }
}

// Function to scrape appointment details from Practice Fusion page
function scrapePFAppointment() {
  console.log('🔍 Scraping PF appointment details...');
  
  const data = {
    patientName: '',
    startTime: '',
    endTime: '',
    appointmentType: '',
    provider: '',
    notes: ''
  };
  
  // Strategy 1: Look for appointment detail labels
  const labels = document.querySelectorAll('label, .label, .field-label, dt, th, .appointment-detail-label, [class*="label"]');
  const values = new Map();
  
  labels.forEach(label => {
    const text = (label.textContent || '').toLowerCase().trim();
    let value = '';
    
    // Find associated value
    const nextSibling = label.nextElementSibling;
    if (nextSibling) {
      value = (nextSibling.textContent || nextSibling.value || '').trim();
    }
    
    // Try parent container
    if (!value) {
      const container = label.closest('.field, .form-group, tr, dl, .appointment-detail, [class*="field"], [class*="group"]');
      if (container) {
        const valueEl = container.querySelector('.value, dd, td:last-child, input, select, .appointment-value, [class*="value"]');
        if (valueEl) {
          value = (valueEl.textContent || valueEl.value || '').trim();
        }
      }
    }
    
    if (value) {
      values.set(text, value);
    }
  });
  
  // Map values to our structure
  for (const [label, value] of values) {
    if ((label.includes('patient') && label.includes('name')) || label === 'patient' || label === 'name') {
      data.patientName = value;
    }
    else if (label.includes('start') && (label.includes('date') || label.includes('time'))) {
      data.startTime = value;
    }
    else if (label.includes('end') && (label.includes('date') || label.includes('time'))) {
      data.endTime = value;
    }
    else if (label.includes('date') || label.includes('time') || label.includes('scheduled')) {
      if (!data.startTime) data.startTime = value;
    }
    else if (label.includes('type') || label.includes('reason') || label.includes('appointment') || label.includes('service') || label.includes('visit')) {
      data.appointmentType = value;
    }
    else if (label.includes('provider') || label.includes('doctor') || label.includes('physician') || label.includes('practitioner')) {
      data.provider = value;
    }
    else if (label.includes('note') || label.includes('comment') || label.includes('description')) {
      data.notes = value;
    }
  }
  
  // Strategy 2: Look for common PF appointment selectors
  if (!data.patientName) {
    const patientSelectors = [
      '.patient-name',
      '[data-patient-name]',
      '.appointment-patient',
      'input[name*="patient" i]',
      '.selected-patient',
      '[class*="patient"][class*="name"]'
    ];
    
    for (const sel of patientSelectors) {
      const el = document.querySelector(sel);
      if (el) {
        data.patientName = (el.textContent || el.value || '').trim();
        if (data.patientName) break;
      }
    }
  }
  
  // Strategy 3: Look for date/time inputs
  if (!data.startTime) {
    const dateInputs = document.querySelectorAll('input[type="datetime-local"], input[type="date"], input[type="time"]');
    const dateValues = [];
    dateInputs.forEach(input => {
      if (input.value) {
        dateValues.push(input.value);
      }
    });
    
    // Combine date and time if separate
    if (dateValues.length >= 2) {
      data.startTime = `${dateValues[0]} ${dateValues[1]}`;
    } else if (dateValues.length === 1) {
      data.startTime = dateValues[0];
    }
  }
  
  // Strategy 4: Look for visible text content that might contain appointment info
  if (!data.patientName || !data.startTime || !data.appointmentType) {
    const headings = document.querySelectorAll('h1, h2, h3, h4, .heading, .title, [class*="title"], [class*="heading"]');
    headings.forEach(h => {
      const text = h.textContent.trim();
      // Look for date patterns
      if (!data.startTime && /\d{1,2}\/\d{1,2}\/\d{4}/.test(text)) {
        data.startTime = text;
      }
      // Look for appointment type patterns
      if (!data.appointmentType && (text.includes('Appointment') || text.includes('Visit') || text.includes('Consultation') || text.includes('Review') || text.includes('Draw'))) {
        data.appointmentType = text;
      }
    });
  }
  
  console.log('📅 Scraped data:', data);
  return data;
}

// Helper function to find GHL contact by name
async function findGHLContactByName(fullName) {
  try {
    const searchUrl = `https://services.leadconnectorhq.com/contacts/?locationId=${GHL_LOCATION_ID}&query=${encodeURIComponent(fullName)}&limit=10`;
    
    const response = await fetch(searchUrl, {
      headers: {
        'Authorization': `Bearer ${GHL_API_KEY}`,
        'Version': '2021-07-28',
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.error('GHL contact search failed:', response.status);
      return null;
    }
    
    const data = await response.json();
    const contacts = data.contacts || [];
    
    // Find exact or close match
    const nameParts = fullName.toLowerCase().split(' ').filter(p => p.length > 0);
    for (const contact of contacts) {
      const contactName = `${contact.firstName || ''} ${contact.lastName || ''}`.toLowerCase().trim();
      
      // Exact match
      if (contactName === fullName.toLowerCase()) {
        return contact.id;
      }
      
      // Close match (both first and last name match)
      const contactParts = contactName.split(' ').filter(p => p.length > 0);
      if (nameParts.length >= 2 && contactParts.length >= 2) {
        if (nameParts.every(part => contactParts.includes(part))) {
          return contact.id;
        }
      }
    }
    
    // If only one result, use it
    if (contacts.length === 1) {
      return contacts[0].id;
    }
    
    return null;
  } catch (error) {
    console.error('Error finding GHL contact:', error);
    return null;
  }
}

// Helper function to map PF appointment type to GHL calendar ID
function getCalendarId(appointmentType) {
  if (!appointmentType) return DEFAULT_CALENDAR_ID;
  
  const type = appointmentType.toLowerCase().trim();
  
  // Check for exact match
  for (const [key, id] of Object.entries(CALENDAR_MAPPINGS)) {
    if (key.toLowerCase() === type) {
      console.log(`✅ Exact calendar match: "${key}" → ${id}`);
      return id;
    }
  }
  
  // Check for partial match
  for (const [key, id] of Object.entries(CALENDAR_MAPPINGS)) {
    if (type.includes(key.toLowerCase()) || key.toLowerCase().includes(type)) {
      console.log(`✅ Partial calendar match: "${key}" → ${id}`);
      return id;
    }
  }
  
  console.log(`⚠️ No calendar mapping found for "${appointmentType}", using default`);
  return DEFAULT_CALENDAR_ID;
}

// Helper function to create appointment in GHL via API
async function createGHLAppointment({ contactId, calendarId, startTime, endTime, title, notes }) {
  try {
    // Parse and format the start time
    let startDate;
    
    // Try parsing various date formats
    if (startTime.includes('T')) {
      startDate = new Date(startTime);
    } else if (startTime.match(/\d{1,2}\/\d{1,2}\/\d{4}/)) {
      // MM/DD/YYYY format
      startDate = new Date(startTime);
    } else {
      // Try generic parsing
      startDate = new Date(startTime);
    }
    
    if (isNaN(startDate.getTime())) {
      console.error('Invalid start time format:', startTime);
      return null;
    }
    
    // Calculate end time (default to 30 minutes if not provided)
    let endDate;
    if (endTime) {
      endDate = new Date(endTime);
      if (isNaN(endDate.getTime())) {
        endDate = new Date(startDate.getTime() + 30 * 60 * 1000);
      }
    } else {
      endDate = new Date(startDate.getTime() + 30 * 60 * 1000);
    }
    
    const appointmentData = {
      calendarId: calendarId,
      contactId: contactId,
      startTime: startDate.toISOString(),
      endTime: endDate.toISOString(),
      title: title || 'Appointment',
      appointmentStatus: 'confirmed'
    };
    
    if (notes) {
      appointmentData.notes = notes;
    }
    
    console.log('📤 Creating GHL appointment:', appointmentData);
    
    const response = await fetch('https://services.leadconnectorhq.com/calendars/events/appointments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GHL_API_KEY}`,
        'Version': '2021-07-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(appointmentData)
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('GHL appointment creation failed:', response.status, errorText);
      return null;
    }
    
    const result = await response.json();
    console.log('✅ GHL appointment created:', result);
    return result;
    
  } catch (error) {
    console.error('Error creating GHL appointment:', error);
    return null;
  }
}
