# Range Medical ↔ Practice Fusion Extension

**Version 1.5.0** - BIDIRECTIONAL Chrome extension for syncing patient data and appointments between Range Medical and Practice Fusion.

## What's New in v1.5.0 🎉
- **✅ BIDIRECTIONAL SYNC**: Capture appointments from Practice Fusion and automatically create them in GoHighLevel
- **✅ ALL CALENDARS MAPPED**: 30+ Range Medical calendars pre-configured
- **✅ SMART MATCHING**: Automatically routes appointments to the correct calendar based on type
- **✅ PATIENT SEARCH**: Finds GHL contacts by name automatically

## Features

### GHL → Practice Fusion (Existing)
1. **Search Patients** - Search your Supabase database by name or phone number
2. **Fill Demographics** - One-click auto-fill of patient demographics on Practice Fusion's Add Patient page
3. **Upload Documents** - Quick access to intake forms and consent PDFs for uploading to patient charts
4. **Fill Appointments** - Auto-populate patient info when creating appointments

### Practice Fusion → GHL (NEW! v1.5.0)
5. **Capture Appointments** - Scrape appointment details from PF and create them in GHL automatically
   - Captures: patient name, date, time, appointment type, provider, notes
   - Searches GHL for the patient
   - Creates appointment in the correct calendar
   - Confirms success

## Installation

### Step 1: Download the Extension
Download and unzip the `range-pf-extension-v1.5.0.zip` file to a folder on your computer (e.g., `Documents/range-pf-extension`).

**Important:** Remember this location - you'll need it for updates!

### Step 2: Open Chrome Extensions
1. Open Chrome
2. Go to `chrome://extensions/` in the address bar
3. Enable **Developer mode** (toggle in the top right corner)

### Step 3: Load the Extension
1. Click **Load unpacked**
2. Select the `range-pf-extension-v1.5.0` folder you unzipped
3. The extension should now appear in your extensions list

### Step 4: Pin the Extension
1. Click the puzzle piece icon in Chrome's toolbar
2. Find "Range Medical ↔ Practice Fusion"
3. Click the pin icon to keep it visible

## Updating the Extension

When a new version is available, you'll see a blue banner in the extension:

1. Click **Download Update**
2. Unzip the new file to the **same folder** as before (replace old files)
3. Go to `chrome://extensions/`
4. Click the **refresh icon** (🔄) on the Range Medical extension
5. Done! You're now on the latest version

## How to Use

### Side Panel
Click the extension icon to open a side panel that stays open as you navigate Practice Fusion.

### Filling Patient Demographics (GHL → PF)

1. In Practice Fusion, go to **Patient Lists** → **Add Patient**
2. Click the Range Medical extension icon (opens side panel)
3. Search for the patient by name or phone number
4. Click on the patient card to select them
5. Click **Fill Demographics**
6. The form will auto-populate with the patient's information
7. Review and click **Save** in Practice Fusion

### Capturing Appointments (PF → GHL) ⭐ NEW!

1. In Practice Fusion, schedule an appointment as you normally would
2. Once the appointment is created, click the Range Medical extension icon
3. Click **Capture PF Appointment → GHL** (green button)
4. The extension will:
   - Extract appointment details from the PF page
   - Find the patient in GHL by name
   - Automatically select the correct GHL calendar based on appointment type
   - Create the appointment in GHL
   - Show success confirmation

**Note:** The patient must already exist as a contact in GHL before capturing their appointment.

### Uploading Documents

1. In Practice Fusion, open the patient's chart
2. Go to the **Documents** tab
3. Click the Range Medical extension icon
4. Search and select the patient
5. Click **Upload Documents**
6. A panel will appear with links to all available documents
7. Click each document to open it, then upload to Practice Fusion

### Creating Appointments

1. In Practice Fusion, go to **Schedule**
2. Click **Add appointment**
3. Click the Range Medical extension icon
4. Search and select the patient
5. Click **Fill Appointment**
6. The patient search field will be populated

## Calendar Mappings

The extension automatically maps Practice Fusion appointment types to the correct GHL calendar:

### Lab/Blood Draw Calendars
- New Patient Blood Draw (Essential & Standard)
- Follow Up Blood Draw
- Initial Lab Review
- Follow Up Lab Review
- Lab Review - Tele-Medicine
- Lab Review - Telephone Call

### Injection Calendars
- Injection - Weight Loss
- Injection - Testosterone
- Injection - Peptide
- Injection - Medical
- Range Injections
- NAD+ Injection (100mg)

### Therapy/Treatment Calendars
- Hyperbaric Oxygen Therapy (HBOT)
- Red Light Therapy
- Range IV / IV Therapy
- High Dose Vitamin C IV
- BYO - IV

### Consultation Calendars
- Initial Consultation
- Initial Consultation - Peptide
- Initial Consultation - Telephone
- Follow-Up Consultation
- The Range Assessment

### Other
- Medication Pickup

The extension uses smart matching - it will match partial appointment types. For example, "Blood Draw" will match "New Patient Blood Draw", and "HBOT" will match "Hyperbaric Oxygen Therapy".

## Field Mapping

| Range Medical Field | Practice Fusion Field |
|--------------------|----------------------|
| first_name | FIRST |
| last_name | LAST |
| email | EMAIL |
| date_of_birth | DATE OF BIRTH |
| gender | SEX |
| phone | MOBILE |
| street_address | ADDRESS LINE 1 |
| city | CITY |
| state | STATE |
| postal_code | ZIP |

## Troubleshooting

### Extension not working?
- Make sure you're on a Practice Fusion page (static.practicefusion.com)
- Try refreshing the Practice Fusion page
- Check that the extension is enabled in `chrome://extensions/`

### Demographics not filling?
- Make sure you're on the Add Patient page
- The page indicator in the extension should show "Ready to fill patient demographics"

### Appointment capture not working?
- **"Could not find patient in GHL"**: Make sure the patient exists as a contact in GHL first. Names must match (first and last).
- **"Could not find appointment details"**: Make sure you're on a PF page that shows appointment details
- **"Failed to create appointment"**: Check browser console (F12) for detailed error logs

### Search not finding patients?
- Try searching by phone number (last 7 digits work)
- Try searching by first and last name together
- Make sure the patient has completed an intake form in Range Medical

### Capture button doesn't appear?
- Make sure you're on a Practice Fusion schedule or appointment page
- Refresh the extension (chrome://extensions/ → click reload)

## Support

For issues or questions:
- Check the browser console (F12) for detailed error logs
- Contact Range Medical support at (949) 997-3988

---
Built for Range Medical © 2026
