// ============================================
// RANGE MEDICAL - PRACTICE FUSION EXTENSION
// Content Script v1.4.0
// ============================================

console.log('🏥 Range Medical extension loaded on Practice Fusion');

// Listen for messages from popup/sidepanel
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Content script received:', request);
  
  if (request.action === 'fillDemographics') {
    const result = fillDemographics(request.patient);
    sendResponse(result);
  }
  
  if (request.action === 'fillAppointment') {
    const result = fillAppointment(request.patientName);
    sendResponse(result);
  }
  
  if (request.action === 'showDocuments') {
    showDocumentPanel(request.documents, request.patientName);
    sendResponse({ success: true });
  }
  
  return true;
});

// Fill demographics function (backup if scripting fails)
function fillDemographics(patient) {
  console.log('🏥 Filling demographics for:', patient);
  
  function findByLabel(labelText) {
    const labels = document.querySelectorAll('label');
    for (const label of labels) {
      if (label.textContent.toUpperCase().includes(labelText.toUpperCase())) {
        const forId = label.getAttribute('for');
        if (forId) return document.getElementById(forId);
        const input = label.querySelector('input, select');
        if (input) return input;
        const next = label.nextElementSibling;
        if (next?.tagName === 'INPUT' || next?.tagName === 'SELECT') return next;
      }
    }
    return null;
  }
  
  function findByDataElement(elementName) {
    return document.querySelector(`[data-element="${elementName}"]`);
  }
  
  function findField(dataElement, ...labelTexts) {
    let el = findByDataElement(dataElement);
    if (el) return el;
    for (const label of labelTexts) {
      el = findByLabel(label);
      if (el) return el;
    }
    for (const label of labelTexts) {
      el = document.querySelector(`input[placeholder*="${label}" i]`);
      if (el) return el;
    }
    for (const label of labelTexts) {
      el = document.querySelector(`input[aria-label*="${label}" i]`);
      if (el) return el;
    }
    return null;
  }
  
  function setVal(el, val) {
    if (!el || !val) return false;
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter) { nativeSetter.call(el, val); } else { el.value = val; }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  
  function simulateTyping(el, text) {
    if (!el || !text) return false;
    el.focus(); el.click();
    el.value = '';
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.select?.();
    for (const char of text) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true, charCode: char.charCodeAt(0) }));
      el.dispatchEvent(new InputEvent('beforeinput', { data: char, inputType: 'insertText', bubbles: true, cancelable: true }));
      const ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (ns) { ns.call(el, el.value + char); } else { el.value += char; }
      el.dispatchEvent(new InputEvent('input', { data: char, inputType: 'insertText', bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return el.value.length > 0;
  }
  
  function setDOB(el, dobStr) {
    if (!el || !dobStr) return false;
    const [year, month, day] = dobStr.split('-');
    const mmddyyyy = `${month}/${day}/${year}`;
    const digitsOnly = `${month}${day}${year}`;
    
    // Strategy 1: date input type
    if (el.type === 'date') {
      const ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (ns) { ns.call(el, dobStr); } else { el.value = dobStr; }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      if (el.value) return true;
    }
    // Strategy 2: Native setter
    const ns = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (ns) { ns.call(el, mmddyyyy); } else { el.value = mmddyyyy; }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    if (el.value && el.value.includes(month)) return true;
    // Strategy 3: Type digits for masked input
    if (simulateTyping(el, digitsOnly) && el.value.length >= 6) return true;
    // Strategy 4: Type MM/DD/YYYY
    if (simulateTyping(el, mmddyyyy) && el.value.includes(month)) return true;
    // Strategy 5: execCommand
    el.focus(); el.select?.();
    try { document.execCommand('selectAll', false, null); document.execCommand('insertText', false, mmddyyyy); if (el.value.includes(month)) return true; } catch(e) {}
    // Strategy 6: Direct fallback
    el.value = mmddyyyy;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return el.value.length > 0;
  }
  
  let filled = 0;
  
  if (setVal(findField('first-name', 'FIRST'), patient.firstName)) filled++;
  if (setVal(findField('last-name', 'LAST'), patient.lastName)) filled++;
  if (setVal(findField('email-address', 'EMAIL'), patient.email)) filled++;
  if (setVal(findField('mobile-phone', 'MOBILE', 'PHONE'), patient.phone?.replace(/\D/g, ''))) filled++;
  if (setVal(findField('address-line1', 'ADDRESS LINE 1', 'ADDRESS'), patient.address)) filled++;
  if (setVal(findField('city', 'CITY'), patient.city)) filled++;
  if (setVal(findField('zip', 'ZIP', 'POSTAL'), patient.zip)) filled++;
  
  if (patient.dob) {
    const dobField = findField('date-of-birth', 'DATE OF BIRTH', 'DOB', 'BIRTH DATE');
    if (dobField) {
      if (setDOB(dobField, patient.dob)) filled++;
    } else {
      const selectors = ['input[name*="birth" i]','input[name*="dob" i]','input[id*="birth" i]','input[id*="dob" i]','input[placeholder*="birth" i]','input[placeholder*="MM/DD" i]'];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) { if (setDOB(el, patient.dob)) { filled++; break; } }
      }
    }
  }
  
  const stateField = findField('state', 'STATE');
  if (stateField && patient.state) {
    if (stateField.tagName === 'SELECT') {
      for (const opt of stateField.querySelectorAll('option')) {
        if (opt.textContent.toLowerCase().includes(patient.state.toLowerCase()) || opt.value.toLowerCase() === patient.state.toLowerCase()) {
          stateField.value = opt.value;
          stateField.dispatchEvent(new Event('change', { bubbles: true }));
          filled++; break;
        }
      }
    } else { setVal(stateField, patient.state); filled++; }
  }
  
  if (patient.gender) {
    const radios = document.querySelectorAll('input[type="radio"]');
    for (const radio of radios) {
      const label = radio.closest('label') || document.querySelector(`label[for="${radio.id}"]`);
      if (label?.textContent.toLowerCase().includes(patient.gender.toLowerCase())) {
        radio.click(); filled++; break;
      }
    }
  }
  
  console.log(`✅ Filled ${filled} fields`);
  return { success: true, fieldsSet: filled };
}

// Fill appointment function
function fillAppointment(patientName) {
  console.log('🏥 Filling appointment for:', patientName);
  
  const searchFields = document.querySelectorAll('input[type="text"], input[placeholder*="patient" i], input[placeholder*="search" i]');
  
  for (const field of searchFields) {
    if (field.offsetParent !== null) {
      field.value = patientName;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
      field.focus();
      console.log('✅ Filled patient search field');
      return { success: true };
    }
  }
  
  console.log('❌ Could not find patient search field');
  return { success: false };
}

// Show document panel
function showDocumentPanel(docs, patientName) {
  const existing = document.getElementById('range-doc-panel');
  if (existing) existing.remove();
  
  const panel = document.createElement('div');
  panel.id = 'range-doc-panel';
  panel.innerHTML = `
    <div style="
      position: fixed;
      top: 20px;
      right: 20px;
      width: 320px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.15);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    ">
      <div style="
        padding: 16px;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
      ">
        <div>
          <div style="font-weight: 600; color: #0f172a;">Documents</div>
          <div style="font-size: 12px; color: #64748b;">${patientName}</div>
        </div>
        <button id="range-close-panel" style="
          background: none;
          border: none;
          font-size: 20px;
          cursor: pointer;
          color: #94a3b8;
          padding: 4px;
        ">×</button>
      </div>
      <div style="padding: 12px; max-height: 400px; overflow-y: auto;">
        ${docs.map(doc => `
          <div style="
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            margin-bottom: 8px;
          ">
            <div style="font-weight: 500; font-size: 13px; color: #0f172a;">${doc.type}</div>
            <a href="${doc.url}" target="_blank" style="
              padding: 8px 12px;
              background: #0ea5e9;
              color: white;
              text-decoration: none;
              border-radius: 6px;
              font-size: 12px;
            ">Open PDF</a>
          </div>
        `).join('')}
      </div>
    </div>
  `;
  
  document.body.appendChild(panel);
  document.getElementById('range-close-panel').addEventListener('click', () => panel.remove());
}
