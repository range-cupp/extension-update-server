// Background service worker for Range Medical extension
// Handles side panel opening

chrome.action.onClicked.addListener(async (tab) => {
  // Open side panel when extension icon is clicked
  await chrome.sidePanel.open({ tabId: tab.id });
});

// Set side panel behavior
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

console.log('Range Medical extension loaded');
